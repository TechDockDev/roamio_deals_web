<form>
    <input type="hidden" wire:model="question_id">
    <div class="form-group">
        <label for="exampleFormControlInput1">Question:</label>
        <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Question" wire:model="question">
        @error('question') <span class="text-danger">{{ $message }}</span>@enderror
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput2">Position:</label>
        <input type="number" class="form-control" id="exampleFormControlInput1" placeholder="Enter Position" wire:model="position">
        @error('position') <span class="text-danger">{{ $message }}</span>@enderror
    </div>
    <button wire:click.prevent="update()" class="btn btn-dark">Update</button>
    <button wire:click.prevent="cancel()" class="btn btn-danger">Cancel</button>
</form>

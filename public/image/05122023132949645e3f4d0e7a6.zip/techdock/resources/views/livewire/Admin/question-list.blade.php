<div>

    @if (session()->has('message'))
        <div class="alert alert-success">
            {{ session('message') }}
        </div>
    @endif

    @if($updateMode)
        @include('livewire.admin.update')
    @else
        @include('livewire.admin.create')
    @endif

    <table class="table table-bordered mt-5">
        <thead>
            <tr>
                <th>ID</th>
                <th>Question</th>
                <th>Postion</th>
                <th width="150px">Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($questions as $question)
            <tr>
                <td>{{ $question->id }}</td>
                <td>{{ $question->question }}</td>
                <td>{{ $question->position }}</td>
                <td>
                <button wire:click="edit({{ $question->id }})" class="btn btn-primary btn-sm">Edit</button>
                    <button wire:click="delete({{ $question->id }})" class="btn btn-danger btn-sm">Delete</button>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

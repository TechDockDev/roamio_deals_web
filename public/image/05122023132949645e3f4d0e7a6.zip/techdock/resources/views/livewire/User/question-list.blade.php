<div>

    @if (session()->has('message'))
        <div class="alert alert-success">
            {{ session('message') }}
        </div>
    @endif

    <table class="table table-bordered mt-5">
        <thead>
            <tr>
                <th>ID</th>
                <th>Question</th>
                <th>Postion</th>
            </tr>
        </thead>
        <tbody wire:sortable="updateQuestionOrder">
            @foreach($questions as $question)
            <tr wire:sortable.item="{{ $question->id }}" wire:key="question-{{ $question->id }}" wire:sortable.handle>
                <td>{{ $question->id }}</td>
                <td>{{ $question->question }}</td>
                <td>{{ $question->position }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>


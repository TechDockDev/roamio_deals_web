<?php

namespace App\Http\Livewire\Admin;

use App\Models\Question;
use Livewire\Component;

class QuestionList extends Component
{
    public $questions, $question, $position, $question_id;
    public $updateMode = false;

    public function render()
    {
        $this->questions = Question::orderBy('position', 'Asc')->get();
        return view('livewire.Admin.question-list');
    }

    private function resetInputFields()
    {
        $this->question = '';
        $this->position = '';
    }

    public function store()
    {
        $validatedDate = $this->validate([
            'question' => 'required',
            'position' => 'required',
        ]);

        Question::create($validatedDate);

        session()->flash('message', 'Question Created Successfully.');

        $this->resetInputFields();
    }

    public function edit($id)
    {
        $question = Question::findOrFail($id);
        $this->question_id = $id;
        $this->question = $question->question;
        $this->position = $question->position;

        $this->updateMode = true;
    }

    public function cancel()
    {
        $this->updateMode = false;
        $this->resetInputFields();
    }

    public function update()
    {
        $validatedDate = $this->validate([
            'question' => 'required',
            'position' => 'required',
        ]);

        $question = Question::find($this->question_id);
        $question->update([
            'question' => $this->question,
            'position' => $this->position,
        ]);

        $this->updateMode = false;

        session()->flash('message', 'Question Updated Successfully.');
        $this->resetInputFields();
    }

    public function delete($id)
    {
        Question::find($id)->delete();
        session()->flash('message', 'Question Deleted Successfully.');
    }
}

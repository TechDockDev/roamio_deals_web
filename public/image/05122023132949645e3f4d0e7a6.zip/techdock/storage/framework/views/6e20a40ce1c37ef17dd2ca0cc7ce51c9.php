<div>

    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <?php if($updateMode): ?>
        <?php echo $__env->make('livewire.admin.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('livewire.admin.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <table class="table table-bordered mt-5">
        <thead>
            <tr>
                <th>ID</th>
                <th>Question</th>
                <th>Postion</th>
                <th width="150px">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($question->id); ?></td>
                <td><?php echo e($question->question); ?></td>
                <td><?php echo e($question->position); ?></td>
                <td>
                <button wire:click="edit(<?php echo e($question->id); ?>)" class="btn btn-primary btn-sm">Edit</button>
                    <button wire:click="delete(<?php echo e($question->id); ?>)" class="btn btn-danger btn-sm">Delete</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\_Projects\_Test_Laravel\techdock\resources\views/livewire/Admin/question-list.blade.php ENDPATH**/ ?>
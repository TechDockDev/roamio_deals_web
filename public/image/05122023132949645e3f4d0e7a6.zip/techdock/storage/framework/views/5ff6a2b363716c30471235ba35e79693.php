<div>

    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-bordered mt-5">
        <thead>
            <tr>
                <th>ID</th>
                <th>Question</th>
                <th>Postion</th>
            </tr>
        </thead>
        <tbody wire:sortable="updateQuestionOrder">
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr wire:sortable.item="<?php echo e($question->id); ?>" wire:key="question-<?php echo e($question->id); ?>" wire:sortable.handle>
                <td><?php echo e($question->id); ?></td>
                <td><?php echo e($question->question); ?></td>
                <td><?php echo e($question->position); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php /**PATH C:\_Projects\_Test_Laravel\techdock\resources\views/livewire/user/question-list.blade.php ENDPATH**/ ?>
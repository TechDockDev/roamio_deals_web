<?php return array (
  'admin.question-list' => 'App\\Http\\Livewire\\Admin\\QuestionList',
  'login' => 'App\\Http\\Livewire\\Login',
  'user.question-list' => 'App\\Http\\Livewire\\User\\QuestionList',
);